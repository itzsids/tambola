# Tambola Number Announcer (Housie Number Caller)

An Android app written in Kotlin and Jetpack Compose (Material 3). It calls Tambola numbers 1–90, announces each one aloud as "Six Three... Sixty-Three", and shows a live 1–90 board.

## How to run it (beginner steps)

1. **Install Android Studio.** Download it free from developer.android.com/studio and install it with the default options.
2. **Unzip this project** somewhere easy to find, like `Documents/TambolaNumberAnnouncer`.
3. **Open it.** Start Android Studio, choose **File > Open**, and select the `TambolaNumberAnnouncer` folder (the one that has `settings.gradle.kts` in it).
4. **Wait for "Gradle sync".** The first time, Android Studio downloads Gradle and the libraries the app needs. This can take 5–10 minutes. Watch the progress bar at the bottom. If it asks to "Trust project", click **Trust**. If it asks to use the Gradle wrapper or to upgrade anything, accept the defaults.
5. **Get a phone or emulator ready:**
   - **Real phone (best, because you can hear the voice):** turn on *Developer options* (Settings > About phone > tap **Build number** 7 times). Then go to Settings > Developer options and turn on **USB debugging**. Connect the phone with a USB cable and tap **Allow** on the phone.
   - **Emulator:** open **Device Manager** on the right side and create a device (for example Pixel 7, API 34).
6. **Press the green ▶ Run button** at the top. The app installs and opens.

To make an APK you can share, go to **Build > Build App Bundle(s) / APK(s) > Build APK(s)**. When it's done, click **locate** to find the file.

## Features
- **Home screen**: pick Auto or Manual mode, set the auto-call interval (3–15 seconds), turn the voice on or off, and reset the board.
- **Auto mode**: Start / Pause / Resume, plus a countdown bar showing when the next number comes.
- **Manual mode**: a big **Next Number** button.
- **Voice**: digit by digit, then the full number ("Six Three... Sixty-Three"). Single-digit numbers are announced as "Single number... Seven". A **Repeat** button says the current number again.
- **Recent Numbers ticker**: scrolls sideways with the newest number first. The newest one is bigger and orange.
- **1–90 board**: called numbers turn green and the latest one turns orange. It also shows Called / Remaining counts.
- **Rotation-safe**: everything is kept in `GameViewModel`, so rotating the phone loses nothing. The screen stays on while the caller screen is open.

## Where things are
| File | What it does |
|---|---|
| `MainActivity.kt` | App entry point. Switches between the Home and Game screens. |
| `GameViewModel.kt` | All game logic: drawing numbers, the auto timer, mute, reset, and saving state. |
| `tts/TtsHelper.kt` | `NumberSpeechFormatter` builds the spoken words. `TambolaSpeaker` wraps Android Text-to-Speech. |
| `ui/HomeScreen.kt` | The mode-selection dashboard. |
| `ui/GameScreen.kt` | The calling screen, with portrait and landscape layouts. |
| `ui/Components.kt` | Current-number card, countdown bar, ticker, stats, 1–90 board, and dialogs. |
| `ui/theme/Theme.kt` | Colours and the light/dark theme. |

## Common tweaks
- **Change how numbers are spoken:** edit `speechParts()` in `tts/TtsHelper.kt`.
- **Change the pause between "Six Three" and "Sixty-Three":** change `PAUSE_BETWEEN_PARTS_MS`.
- **Make the voice faster or slower:** change `SPEECH_RATE` (1.0 = normal).
- **Change the interval range:** change `MIN_INTERVAL` / `MAX_INTERVAL` in `GameViewModel.kt`.

## If there's no voice
Check that the phone volume (media volume) is up and that a Text-to-Speech engine is installed: Settings > Accessibility > Text-to-speech output, then choose "Speech Services by Google". The app shows a notice if it can't find one.
