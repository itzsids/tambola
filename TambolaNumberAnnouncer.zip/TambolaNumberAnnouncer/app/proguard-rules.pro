# No custom rules needed. Minification is disabled for this project.
