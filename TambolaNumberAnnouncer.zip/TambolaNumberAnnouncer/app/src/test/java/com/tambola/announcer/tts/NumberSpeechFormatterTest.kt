package com.tambola.announcer.tts

import org.junit.Assert.assertEquals
import org.junit.Test

class NumberSpeechFormatterTest {

    @Test
    fun twoDigitNumber_isSpokenDigitByDigitThenFull() {
        assertEquals("Six Three" to "Sixty-Three", NumberSpeechFormatter.speechParts(63))
        assertEquals("Six Three... Sixty-Three", NumberSpeechFormatter.displayText(63))
    }

    @Test
    fun roundTens_haveNoHyphen() {
        assertEquals("Nine Zero" to "Ninety", NumberSpeechFormatter.speechParts(90))
        assertEquals("Two Zero" to "Twenty", NumberSpeechFormatter.speechParts(20))
    }

    @Test
    fun teens_useTeenWords() {
        assertEquals("One Three" to "Thirteen", NumberSpeechFormatter.speechParts(13))
        assertEquals("One Zero" to "Ten", NumberSpeechFormatter.speechParts(10))
    }

    @Test
    fun singleDigits_saySingleNumber() {
        assertEquals("Single number" to "Seven", NumberSpeechFormatter.speechParts(7))
    }

    @Test
    fun everyNumberFrom1To90_hasWords() {
        for (n in 1..90) {
            val (a, b) = NumberSpeechFormatter.speechParts(n)
            assert(a.isNotBlank() && b.isNotBlank())
        }
    }
}
