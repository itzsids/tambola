package com.tambola.announcer.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.VolumeOff
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Replay
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.OutlinedIconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tambola.announcer.CallMode
import com.tambola.announcer.GameUiState
import com.tambola.announcer.tts.TambolaSpeaker

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GameScreen(
    state: GameUiState,
    onBack: () -> Unit,
    onStartPause: () -> Unit,
    onNext: () -> Unit,
    onRepeat: () -> Unit,
    onReset: () -> Unit,
    onToggleMute: () -> Unit,
) {
    KeepScreenOn()
    var showResetDialog by rememberSaveable { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Tambola Caller", fontWeight = FontWeight.Bold)
                        Text(
                            text = if (state.mode == CallMode.AUTO) {
                                "Auto mode - every ${state.intervalSeconds}s"
                            } else {
                                "Manual mode"
                            },
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back to home")
                    }
                },
                actions = {
                    IconButton(onClick = onToggleMute) {
                        Icon(
                            imageVector = if (state.isMuted) {
                                Icons.AutoMirrored.Filled.VolumeOff
                            } else {
                                Icons.AutoMirrored.Filled.VolumeUp
                            },
                            contentDescription = if (state.isMuted) "Unmute voice" else "Mute voice",
                        )
                    }
                },
            )
        },
    ) { innerPadding ->
        BoxWithConstraints(
            Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            val isLandscape = maxWidth > maxHeight

            if (isLandscape) {
                // Side by side: caller on the left, board on the right.
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(16.dp),
                ) {
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight()
                            .verticalScroll(rememberScrollState())
                            .padding(vertical = 12.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        CallerSection(state, onStartPause, onNext, onRepeat) { showResetDialog = true }
                    }
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight()
                            .verticalScroll(rememberScrollState())
                            .padding(vertical = 12.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        NumberBoard(state.calledNumbers)
                    }
                }
            } else {
                // Portrait: everything stacked in one column, sized to fit one screen.
                // (It can still scroll on very small phones.)
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .verticalScroll(rememberScrollState())
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    CallerSection(state, onStartPause, onNext, onRepeat) { showResetDialog = true }
                    NumberBoard(state.calledNumbers)
                }
            }
        }
    }

    if (showResetDialog) {
        ResetConfirmDialog(
            onConfirm = {
                showResetDialog = false
                onReset()
            },
            onDismiss = { showResetDialog = false },
        )
    }
}

/** Current number + countdown + buttons + recent ticker. */
@Composable
private fun CallerSection(
    state: GameUiState,
    onStartPause: () -> Unit,
    onNext: () -> Unit,
    onRepeat: () -> Unit,
    onResetClick: () -> Unit,
) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        if (state.voiceStatus == TambolaSpeaker.Status.UNAVAILABLE) {
            VoiceUnavailableNotice()
        }
        CurrentNumberCard(state)
        if (state.mode == CallMode.AUTO) {
            CountdownBar(state)
        }
        GameControls(state, onStartPause, onNext, onRepeat, onResetClick)
        RecentNumbersTicker(state.calledNumbers)
    }
}

@Composable
private fun GameControls(
    state: GameUiState,
    onStartPause: () -> Unit,
    onNext: () -> Unit,
    onRepeat: () -> Unit,
    onResetClick: () -> Unit,
) {
    // Main button + Repeat + Reset all on ONE row to save vertical space.
    Row(
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (state.mode == CallMode.AUTO) {
            Button(
                onClick = onStartPause,
                enabled = !state.isComplete,
                modifier = Modifier
                    .weight(1f)
                    .height(56.dp),
                shape = RoundedCornerShape(16.dp),
            ) {
                Icon(
                    if (state.isRunning) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                    contentDescription = null,
                )
                Spacer(Modifier.width(8.dp))
                Text(
                    text = when {
                        state.isRunning -> "Pause"
                        state.hasStarted -> "Resume"
                        else -> "Start"
                    },
                    fontSize = 18.sp,
                    fontWeight = FontWeight.SemiBold,
                )
            }
        } else {
            Button(
                onClick = onNext,
                enabled = !state.isComplete,
                modifier = Modifier
                    .weight(1f)
                    .height(56.dp),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.tertiary,
                    contentColor = MaterialTheme.colorScheme.onTertiary,
                ),
            ) {
                Icon(Icons.Filled.SkipNext, contentDescription = null)
                Spacer(Modifier.width(6.dp))
                Text("Next Number", fontSize = 18.sp, fontWeight = FontWeight.Bold, maxLines = 1)
            }
        }

        OutlinedIconButton(
            onClick = onRepeat,
            enabled = state.currentNumber != null && !state.isMuted,
            modifier = Modifier.size(56.dp),
        ) {
            Icon(Icons.Filled.Replay, contentDescription = "Repeat number")
        }
        OutlinedIconButton(
            onClick = onResetClick,
            enabled = state.hasStarted,
            modifier = Modifier.size(56.dp),
            colors = IconButtonDefaults.outlinedIconButtonColors(
                contentColor = MaterialTheme.colorScheme.error,
            ),
        ) {
            Icon(Icons.Filled.Refresh, contentDescription = "Reset game")
        }
    }
}

/** Stops the phone screen from turning off while the caller screen is open. */
@Composable
private fun KeepScreenOn() {
    val view = LocalView.current
    DisposableEffect(view) {
        view.keepScreenOn = true
        onDispose { view.keepScreenOn = false }
    }
}
