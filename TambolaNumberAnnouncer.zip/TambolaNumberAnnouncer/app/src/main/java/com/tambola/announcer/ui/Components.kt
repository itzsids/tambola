package com.tambola.announcer.ui

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tambola.announcer.CallMode
import com.tambola.announcer.GameUiState
import com.tambola.announcer.tts.NumberSpeechFormatter
import com.tambola.announcer.ui.theme.CalledGreenDark
import com.tambola.announcer.ui.theme.CalledGreenLight
import com.tambola.announcer.ui.theme.TambolaGradient

/** The big banner showing the number that was just called. */
@Composable
fun CurrentNumberCard(state: GameUiState, modifier: Modifier = Modifier) {
    val number = state.currentNumber

    val topLabel = when {
        state.isComplete -> "FULL HOUSE! All 90 numbers called"
        number == null -> "Ready to start"
        else -> "Number ${state.calledCount} of ${GameUiState.TOTAL_NUMBERS}"
    }
    val bottomLabel = when {
        number != null -> NumberSpeechFormatter.displayText(number)
        state.mode == CallMode.AUTO -> "Press Start to begin calling"
        else -> "Press Next Number to begin"
    }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(24.dp))
            .background(TambolaGradient)
            .padding(vertical = 10.dp, horizontal = 16.dp),
        contentAlignment = Alignment.Center,
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = topLabel,
                color = Color.White.copy(alpha = 0.85f),
                style = MaterialTheme.typography.labelLarge,
                textAlign = TextAlign.Center,
            )
            AnimatedContent(
                targetState = number,
                transitionSpec = {
                    (scaleIn(initialScale = 0.5f) + fadeIn()) togetherWith
                        (scaleOut(targetScale = 1.4f) + fadeOut())
                },
                label = "currentNumber",
            ) { shown ->
                Text(
                    text = shown?.toString() ?: "--",
                    color = Color.White,
                    fontSize = 64.sp,
                    lineHeight = 70.sp,
                    fontWeight = FontWeight.Black,
                )
            }
            Text(
                text = bottomLabel,
                color = Color.White,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Medium,
                textAlign = TextAlign.Center,
            )
        }
    }
}

/** Auto mode: shows how long until the next number is called. */
@Composable
fun CountdownBar(state: GameUiState, modifier: Modifier = Modifier) {
    val label = when {
        state.isComplete -> "Game complete"
        state.isRunning -> "Next number in ${state.secondsUntilNext}s"
        state.hasStarted -> "Paused"
        else -> "Press Start to begin"
    }
    Column(modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
            Text(
                "Every ${state.intervalSeconds}s",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        Spacer(Modifier.height(4.dp))
        LinearProgressIndicator(
            progress = { state.countdownProgress },
            modifier = Modifier
                .fillMaxWidth()
                .height(8.dp)
                .clip(RoundedCornerShape(4.dp)),
            color = MaterialTheme.colorScheme.tertiary,
            trackColor = MaterialTheme.colorScheme.surfaceVariant,
        )
    }
}

/** Horizontal, scrollable list of called numbers, newest first. */
@Composable
fun RecentNumbersTicker(calledNumbers: List<Int>, modifier: Modifier = Modifier) {
    val newestFirst = remember(calledNumbers) { calledNumbers.asReversed().toList() }
    val listState = rememberLazyListState()

    // Whenever a new number arrives, scroll back to the start so it is visible.
    LaunchedEffect(calledNumbers.size) {
        if (calledNumbers.isNotEmpty()) listState.animateScrollToItem(0)
    }

    Card(modifier.fillMaxWidth()) {
        Column(Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text(
                    "Recent Numbers",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.weight(1f),
                )
                Text(
                    "Latest first",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Spacer(Modifier.height(6.dp))
            if (newestFirst.isEmpty()) {
                Text(
                    "Called numbers will appear here.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            } else {
                LazyRow(
                    state = listState,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    contentPadding = PaddingValues(vertical = 4.dp),
                ) {
                    itemsIndexed(newestFirst, key = { _, n -> n }) { index, n ->
                        NumberBall(
                            number = n,
                            isLatest = index == 0,
                            modifier = Modifier.animateItem(),
                        )
                    }
                }
            }
        }
    }
}

/** A round "ball" with a number. The latest one is larger and orange. */
@Composable
fun NumberBall(number: Int, isLatest: Boolean, modifier: Modifier = Modifier) {
    val colors = MaterialTheme.colorScheme
    val size = if (isLatest) 46.dp else 38.dp
    val background = if (isLatest) colors.tertiary else colors.secondaryContainer
    val textColor = if (isLatest) colors.onTertiary else colors.onSecondaryContainer

    Box(
        modifier = modifier
            .size(size)
            .clip(CircleShape)
            .background(background)
            .then(
                if (isLatest) Modifier.border(3.dp, colors.tertiaryContainer, CircleShape)
                else Modifier
            ),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = number.toString(),
            color = textColor,
            fontWeight = FontWeight.Bold,
            fontSize = if (isLatest) 19.sp else 15.sp,
        )
    }
}

/** The 1-90 checker board, 9 rows of 10. Called numbers turn green, the latest turns orange. */
@Composable
fun NumberBoard(calledNumbers: List<Int>, modifier: Modifier = Modifier) {
    val calledSet = remember(calledNumbers) { calledNumbers.toHashSet() }
    val latest = calledNumbers.lastOrNull()
    val calledColor = if (isSystemInDarkTheme()) CalledGreenDark else CalledGreenLight
    val colors = MaterialTheme.colorScheme

    Card(modifier.fillMaxWidth()) {
        Column(Modifier.padding(horizontal = 10.dp, vertical = 8.dp)) {
            // Title and colour legend share one line to save space.
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text(
                    "Board",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.weight(1f),
                )
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    LegendItem(calledColor, "Called")
                    LegendItem(colors.tertiary, "Latest")
                }
            }
            Spacer(Modifier.height(6.dp))

            for (row in 0 until 9) {
                Row(Modifier.fillMaxWidth()) {
                    for (col in 1..10) {
                        val n = row * 10 + col
                        BoardCell(
                            number = n,
                            isCalled = n in calledSet,
                            isLatest = n == latest,
                            calledColor = calledColor,
                            modifier = Modifier.weight(1f),
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun BoardCell(
    number: Int,
    isCalled: Boolean,
    isLatest: Boolean,
    calledColor: Color,
    modifier: Modifier = Modifier,
) {
    val colors = MaterialTheme.colorScheme
    val background by animateColorAsState(
        targetValue = when {
            isLatest -> colors.tertiary
            isCalled -> calledColor
            else -> colors.surfaceVariant
        },
        label = "cellColor",
    )
    val textColor = when {
        isLatest -> colors.onTertiary
        isCalled -> Color.White
        else -> colors.onSurfaceVariant
    }

    Box(
        modifier = modifier
            .aspectRatio(1.2f) // slightly wider than tall, so the board is shorter
            .padding(2.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(background),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = number.toString(),
            color = textColor,
            fontSize = 13.sp,
            fontWeight = if (isCalled) FontWeight.Bold else FontWeight.Medium,
            maxLines = 1,
        )
    }
}

@Composable
private fun LegendItem(color: Color, label: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier
                .size(12.dp)
                .clip(RoundedCornerShape(3.dp))
                .background(color)
        )
        Spacer(Modifier.width(4.dp))
        Text(label, style = MaterialTheme.typography.labelSmall)
    }
}

/** Asks "are you sure?" before wiping the board. */
@Composable
fun ResetConfirmDialog(onConfirm: () -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        icon = { Icon(Icons.Filled.Refresh, contentDescription = null) },
        title = { Text("Reset game?") },
        text = { Text("This clears all called numbers and the board. It can't be undone.") },
        confirmButton = {
            TextButton(onClick = onConfirm) {
                Text("Reset", color = MaterialTheme.colorScheme.error)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        },
    )
}

/** Helpful card shown if the phone has no working Text-to-Speech voice. */
@Composable
fun VoiceUnavailableNotice(modifier: Modifier = Modifier) {
    Card(
        modifier = modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.errorContainer,
            contentColor = MaterialTheme.colorScheme.onErrorContainer,
        ),
    ) {
        Text(
            "Voice is not available. Install or enable a Text-to-Speech engine " +
                "(Settings > Accessibility > Text-to-speech output). The game still works without sound.",
            modifier = Modifier.padding(12.dp),
            style = MaterialTheme.typography.bodySmall,
        )
    }
}
