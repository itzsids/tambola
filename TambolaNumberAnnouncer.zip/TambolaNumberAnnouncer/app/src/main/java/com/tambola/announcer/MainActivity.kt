package com.tambola.announcer

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.Crossfade
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.tambola.announcer.ui.GameScreen
import com.tambola.announcer.ui.HomeScreen
import com.tambola.announcer.ui.theme.TambolaTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            TambolaTheme {
                TambolaApp()
            }
        }
    }
}

/**
 * Root of the app. Reads the state from the ViewModel and shows either the
 * Home screen or the Game screen. viewModel() returns the SAME GameViewModel
 * after a rotation, which is why nothing is lost.
 */
@Composable
fun TambolaApp(viewModel: GameViewModel = viewModel()) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()

    Crossfade(targetState = state.screen, label = "screen") { screen ->
        when (screen) {
            Screen.HOME -> HomeScreen(
                state = state,
                onModeSelected = viewModel::selectMode,
                onIntervalChanged = viewModel::setInterval,
                onToggleMute = viewModel::toggleMute,
                onStartGame = viewModel::openGame,
                onResetGame = viewModel::resetGame,
            )

            Screen.GAME -> {
                // Phone's back button/gesture returns to Home (and pauses auto-calling).
                BackHandler(onBack = viewModel::goHome)
                GameScreen(
                    state = state,
                    onBack = viewModel::goHome,
                    onStartPause = viewModel::toggleStartPause,
                    onNext = viewModel::nextNumber,
                    onRepeat = viewModel::repeatCurrent,
                    onReset = viewModel::resetGame,
                    onToggleMute = viewModel::toggleMute,
                )
            }
        }
    }
}
