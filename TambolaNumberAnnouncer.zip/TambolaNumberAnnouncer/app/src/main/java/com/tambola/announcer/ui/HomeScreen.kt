package com.tambola.announcer.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.VolumeOff
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tambola.announcer.CallMode
import com.tambola.announcer.GameUiState
import com.tambola.announcer.tts.TambolaSpeaker
import com.tambola.announcer.ui.theme.TambolaGradient
import kotlin.math.roundToInt

@Composable
fun HomeScreen(
    state: GameUiState,
    onModeSelected: (CallMode) -> Unit,
    onIntervalChanged: (Int) -> Unit,
    onToggleMute: () -> Unit,
    onStartGame: () -> Unit,
    onResetGame: () -> Unit,
) {
    // rememberSaveable keeps the dialog open across rotation too.
    var showResetDialog by rememberSaveable { mutableStateOf(false) }

    Scaffold { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentAlignment = Alignment.TopCenter,
        ) {
            Column(
                modifier = Modifier
                    .widthIn(max = 640.dp) // looks neat on tablets / landscape
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 20.dp, vertical = 16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
            ) {
                HomeHeader()

                Text(
                    "Choose a calling mode",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                )
                ModeCard(
                    title = "Auto Caller",
                    description = "Numbers are called automatically every few seconds.",
                    icon = Icons.Filled.Timer,
                    selected = state.mode == CallMode.AUTO,
                    onClick = { onModeSelected(CallMode.AUTO) },
                )
                ModeCard(
                    title = "Manual Caller",
                    description = "You tap \"Next Number\" each time you want a new number.",
                    icon = Icons.Filled.TouchApp,
                    selected = state.mode == CallMode.MANUAL,
                    onClick = { onModeSelected(CallMode.MANUAL) },
                )

                AnimatedVisibility(visible = state.mode == CallMode.AUTO) {
                    IntervalCard(seconds = state.intervalSeconds, onChange = onIntervalChanged)
                }

                VoiceCard(
                    isMuted = state.isMuted,
                    voiceStatus = state.voiceStatus,
                    onToggleMute = onToggleMute,
                )

                GameStatusCard(state = state, onResetClick = { showResetDialog = true })

                Button(
                    onClick = onStartGame,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(60.dp),
                    shape = RoundedCornerShape(18.dp),
                ) {
                    Icon(Icons.Filled.PlayArrow, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text(
                        text = when {
                            state.isComplete -> "View Finished Game"
                            state.hasStarted -> "Resume Game"
                            else -> "Start Game"
                        },
                        fontSize = 18.sp,
                        fontWeight = FontWeight.SemiBold,
                    )
                }
            }
        }
    }

    if (showResetDialog) {
        ResetConfirmDialog(
            onConfirm = {
                showResetDialog = false
                onResetGame()
            },
            onDismiss = { showResetDialog = false },
        )
    }
}

@Composable
private fun HomeHeader() {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(28.dp))
            .background(TambolaGradient)
            .padding(24.dp),
    ) {
        Column {
            Text("Tambola", color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.Black)
            Text(
                "Number Announcer",
                color = Color.White,
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.SemiBold,
            )
            Spacer(Modifier.height(4.dp))
            Text(
                "Housie caller with voice announcements",
                color = Color.White.copy(alpha = 0.85f),
                style = MaterialTheme.typography.bodyMedium,
            )
            Spacer(Modifier.height(16.dp))
            // Decorative number balls
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(7, 23, 45, 63, 90).forEach { n ->
                    Box(
                        Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(Color.White),
                        contentAlignment = Alignment.Center,
                    ) {
                        Text(n.toString(), color = Color(0xFF3949AB), fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
private fun ModeCard(
    title: String,
    description: String,
    icon: ImageVector,
    selected: Boolean,
    onClick: () -> Unit,
) {
    val colors = MaterialTheme.colorScheme
    Card(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (selected) colors.primaryContainer else colors.surfaceVariant.copy(alpha = 0.5f),
        ),
        border = if (selected) BorderStroke(2.dp, colors.primary) else null,
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(
                Modifier
                    .size(48.dp)
                    .clip(CircleShape)
                    .background(if (selected) colors.primary else colors.secondaryContainer),
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    icon,
                    contentDescription = null,
                    tint = if (selected) colors.onPrimary else colors.onSecondaryContainer,
                )
            }
            Spacer(Modifier.width(16.dp))
            Column(Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text(description, style = MaterialTheme.typography.bodyMedium, color = colors.onSurfaceVariant)
            }
            RadioButton(selected = selected, onClick = onClick)
        }
    }
}

@Composable
private fun IntervalCard(seconds: Int, onChange: (Int) -> Unit) {
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp)) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    "Auto-call interval",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.weight(1f),
                )
                Text(
                    "$seconds sec",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                )
            }
            Slider(
                value = seconds.toFloat(),
                onValueChange = { onChange(it.roundToInt()) },
                valueRange = GameUiState.MIN_INTERVAL.toFloat()..GameUiState.MAX_INTERVAL.toFloat(),
                // 3..15 = 13 positions; "steps" counts only the ones in between.
                steps = GameUiState.MAX_INTERVAL - GameUiState.MIN_INTERVAL - 1,
            )
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("${GameUiState.MIN_INTERVAL}s (fast)", style = MaterialTheme.typography.labelSmall)
                Text("${GameUiState.MAX_INTERVAL}s (slow)", style = MaterialTheme.typography.labelSmall)
            }
        }
    }
}

@Composable
private fun VoiceCard(
    isMuted: Boolean,
    voiceStatus: TambolaSpeaker.Status,
    onToggleMute: () -> Unit,
) {
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp)) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(
                if (isMuted) Icons.AutoMirrored.Filled.VolumeOff else Icons.AutoMirrored.Filled.VolumeUp,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
            )
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text("Voice announcer", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                Text(
                    text = when (voiceStatus) {
                        TambolaSpeaker.Status.INITIALIZING -> "Getting voice ready..."
                        TambolaSpeaker.Status.UNAVAILABLE -> "No Text-to-Speech voice found on this phone"
                        TambolaSpeaker.Status.READY -> "Says e.g. \"Six Three... Sixty-Three\""
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Switch(checked = !isMuted, onCheckedChange = { onToggleMute() })
        }
    }
}

@Composable
private fun GameStatusCard(state: GameUiState, onResetClick: () -> Unit) {
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp)) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(Modifier.weight(1f)) {
                Text("Game board", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                Text(
                    text = if (state.hasStarted) {
                        "Called: ${state.calledCount} / ${GameUiState.TOTAL_NUMBERS} | Remaining: ${state.remainingCount}"
                    } else {
                        "Fresh board - no numbers called yet"
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            OutlinedButton(
                onClick = onResetClick,
                enabled = state.hasStarted,
                colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error),
            ) {
                Icon(Icons.Filled.Refresh, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(4.dp))
                Text("Reset")
            }
        }
    }
}
