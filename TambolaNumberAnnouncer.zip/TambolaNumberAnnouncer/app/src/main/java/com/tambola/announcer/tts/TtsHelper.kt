package com.tambola.announcer.tts

import android.content.Context
import android.speech.tts.TextToSpeech
import java.util.Locale

/**
 * Turns a Tambola number (1..90) into the words the announcer speaks.
 *
 * Format: digit-by-digit first, then the full number.
 *   63 -> "Six Three"  ...  "Sixty-Three"
 *   90 -> "Nine Zero"  ...  "Ninety"
 *    7 -> "Single number" ... "Seven"   (single digits have no second digit to read out)
 *
 * This object is pure Kotlin (no Android classes), so it can be unit-tested easily.
 */
object NumberSpeechFormatter {

    private val ONES = arrayOf(
        "Zero", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine",
        "Ten", "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen",
        "Seventeen", "Eighteen", "Nineteen"
    )

    private val TENS = arrayOf(
        "", "", "Twenty", "Thirty", "Forty", "Fifty", "Sixty", "Seventy", "Eighty", "Ninety"
    )

    /** 63 -> "Sixty-Three", 40 -> "Forty", 12 -> "Twelve". */
    fun toWords(number: Int): String {
        require(number in 0..99) { "Only numbers 0..99 are supported, got $number" }
        return when {
            number < 20 -> ONES[number]
            number % 10 == 0 -> TENS[number / 10]
            else -> "${TENS[number / 10]}-${ONES[number % 10]}"
        }
    }

    /** 63 -> "Six Three", 90 -> "Nine Zero". */
    fun digitByDigit(number: Int): String =
        number.toString().map { ONES[it.digitToInt()] }.joinToString(" ")

    /**
     * The two phrases spoken for a number, with a short pause between them.
     * first  = digit-by-digit part
     * second = full number
     */
    fun speechParts(number: Int): Pair<String, String> =
        if (number < 10) {
            "Single number" to toWords(number)
        } else {
            digitByDigit(number) to toWords(number)
        }

    /** Text shown on screen under the big number, e.g. "Six Three... Sixty-Three". */
    fun displayText(number: Int): String {
        val (first, second) = speechParts(number)
        return "$first... $second"
    }
}

/**
 * Small wrapper around Android's built-in [TextToSpeech] engine.
 *
 * Create it once (the GameViewModel does this with the Application context so it
 * survives screen rotation), call [announce] for each number, and [shutdown] when done.
 */
class TambolaSpeaker(context: Context) : TextToSpeech.OnInitListener {

    enum class Status { INITIALIZING, READY, UNAVAILABLE }

    // Always use the application context so we never leak an Activity.
    private val tts = TextToSpeech(context.applicationContext, this)

    var status: Status = Status.INITIALIZING
        private set

    private var statusListener: ((Status) -> Unit)? = null

    /** Registers a listener and immediately tells it the current status. */
    fun setOnStatusChangedListener(listener: (Status) -> Unit) {
        statusListener = listener
        listener(status)
    }

    /** Called by Android (on the main thread) when the TTS engine has started up. */
    override fun onInit(result: Int) {
        status = if (result == TextToSpeech.SUCCESS && configureLanguage()) {
            tts.setSpeechRate(SPEECH_RATE)
            Status.READY
        } else {
            Status.UNAVAILABLE
        }
        statusListener?.invoke(status)
    }

    /** Tries Indian English first, then other English voices. */
    private fun configureLanguage(): Boolean {
        val preferred = listOf(
            Locale.forLanguageTag("en-IN"),
            Locale.UK,
            Locale.US,
            Locale.ENGLISH
        )
        for (locale in preferred) {
            val result = tts.setLanguage(locale)
            if (result >= TextToSpeech.LANG_AVAILABLE) return true
        }
        return false
    }

    /**
     * Speaks a number as: "<digits>" + short pause + "<full number>".
     * QUEUE_FLUSH on the first part cuts off any older announcement still playing,
     * so a fast auto-caller never builds up a backlog of speech.
     */
    fun announce(number: Int) {
        if (status != Status.READY) return
        val (digits, full) = NumberSpeechFormatter.speechParts(number)
        tts.speak(digits, TextToSpeech.QUEUE_FLUSH, null, "digits_$number")
        tts.playSilentUtterance(PAUSE_BETWEEN_PARTS_MS, TextToSpeech.QUEUE_ADD, "pause_$number")
        tts.speak(full, TextToSpeech.QUEUE_ADD, null, "full_$number")
    }

    /** Stops whatever is being spoken right now. */
    fun stop() {
        if (status == Status.READY) tts.stop()
    }

    /** Releases the engine. Call once, when the speaker is no longer needed. */
    fun shutdown() {
        statusListener = null
        tts.stop()
        tts.shutdown()
    }

    private companion object {
        const val PAUSE_BETWEEN_PARTS_MS = 450L
        const val SPEECH_RATE = 0.9f
    }
}
