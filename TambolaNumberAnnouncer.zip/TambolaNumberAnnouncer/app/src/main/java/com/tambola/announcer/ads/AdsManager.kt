package com.tambola.announcer.ads

import android.app.Activity
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.google.android.ump.ConsentInformation
import com.google.android.ump.ConsentRequestParameters
import com.google.android.ump.UserMessagingPlatform
import com.tambola.announcer.BuildConfig
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Everything to do with ads lives here.
 *
 * 1. On app start we ask Google's consent tool (UMP) whether this user needs a
 *    consent popup (only users in Europe/UK see one). This is required by AdMob.
 * 2. Once ads are allowed we start the Mobile Ads SDK.
 * 3. Banners show at the bottom of the screens (see BannerAd.kt).
 * 4. A full-screen "interstitial" ad may show after the user resets a game,
 *    at most once every [MIN_GAP_BETWEEN_INTERSTITIALS_MS].
 */
object AdsManager {

    /** True once ads are allowed and the SDK has been started. The UI watches this. */
    var canShowAds by mutableStateOf(false)
        private set

    /** True if the user is in a region where we must offer a "Privacy settings" button. */
    var privacyOptionsRequired by mutableStateOf(false)
        private set

    private val sdkStarted = AtomicBoolean(false)
    private var interstitial: InterstitialAd? = null
    private var isLoadingInterstitial = false
    private var lastInterstitialShownAt = 0L

    private const val MIN_GAP_BETWEEN_INTERSTITIALS_MS = 3 * 60 * 1000L // 3 minutes

    /** Call once from MainActivity.onCreate. */
    fun gatherConsentAndStart(activity: Activity) {
        val consentInfo = UserMessagingPlatform.getConsentInformation(activity)
        val params = ConsentRequestParameters.Builder().build()

        consentInfo.requestConsentInfoUpdate(
            activity,
            params,
            {
                // Shows the consent form only if this user needs one (e.g. in Europe).
                UserMessagingPlatform.loadAndShowConsentFormIfRequired(activity) { _ ->
                    privacyOptionsRequired = consentInfo.privacyOptionsRequirementStatus ==
                        ConsentInformation.PrivacyOptionsRequirementStatus.REQUIRED
                    if (consentInfo.canRequestAds()) startSdk(activity.applicationContext)
                }
            },
            { _ ->
                // Couldn't reach Google right now; use the answer saved last time, if any.
                if (consentInfo.canRequestAds()) startSdk(activity.applicationContext)
            },
        )

        // If the user already answered on a previous launch, start straight away.
        if (consentInfo.canRequestAds()) startSdk(activity.applicationContext)
    }

    /** Opens the consent form again so the user can change their choice. */
    fun showPrivacyOptions(activity: Activity) {
        UserMessagingPlatform.showPrivacyOptionsForm(activity) { _ -> }
    }

    private fun startSdk(appContext: Context) {
        if (!sdkStarted.compareAndSet(false, true)) return
        // Google recommends starting the SDK off the main thread.
        Thread {
            MobileAds.initialize(appContext) {}
            Handler(Looper.getMainLooper()).post {
                canShowAds = true
                loadInterstitial(appContext)
            }
        }.start()
    }

    private fun loadInterstitial(context: Context) {
        if (!canShowAds || interstitial != null || isLoadingInterstitial) return
        isLoadingInterstitial = true
        InterstitialAd.load(
            context.applicationContext,
            BuildConfig.INTERSTITIAL_AD_ID,
            AdRequest.Builder().build(),
            object : InterstitialAdLoadCallback() {
                override fun onAdLoaded(ad: InterstitialAd) {
                    interstitial = ad
                    isLoadingInterstitial = false
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    interstitial = null
                    isLoadingInterstitial = false
                }
            },
        )
    }

    /**
     * Shows a full-screen ad if one is ready and enough time has passed since the last one.
     * Safe to call any time: if no ad is ready it just loads one for next time.
     */
    fun maybeShowInterstitial(activity: Activity?) {
        if (activity == null || !canShowAds) return
        val ad = interstitial
        if (ad == null) {
            loadInterstitial(activity)
            return
        }
        val now = SystemClock.elapsedRealtime()
        if (lastInterstitialShownAt != 0L && now - lastInterstitialShownAt < MIN_GAP_BETWEEN_INTERSTITIALS_MS) {
            return
        }

        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() {
                interstitial = null
                loadInterstitial(activity)
            }

            override fun onAdFailedToShowFullScreenContent(error: AdError) {
                interstitial = null
                loadInterstitial(activity)
            }
        }
        lastInterstitialShownAt = now
        interstitial = null
        ad.show(activity)
    }
}
