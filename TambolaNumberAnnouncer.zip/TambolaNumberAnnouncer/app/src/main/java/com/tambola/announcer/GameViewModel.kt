package com.tambola.announcer

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.viewModelScope
import com.tambola.announcer.tts.TambolaSpeaker
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.ceil

enum class Screen { HOME, GAME }

enum class CallMode { AUTO, MANUAL }

/**
 * Everything the UI needs to draw itself. The UI only ever reads this;
 * it changes it by calling functions on [GameViewModel].
 */
data class GameUiState(
    val screen: Screen = Screen.HOME,
    val mode: CallMode = CallMode.AUTO,
    val intervalSeconds: Int = DEFAULT_INTERVAL,
    /** Called numbers in the order they were called (oldest first). */
    val calledNumbers: List<Int> = emptyList(),
    val isRunning: Boolean = false,
    val isMuted: Boolean = false,
    /** Milliseconds passed in the current auto-call countdown. */
    val elapsedMs: Long = 0L,
    val voiceStatus: TambolaSpeaker.Status = TambolaSpeaker.Status.INITIALIZING,
) {
    val currentNumber: Int? get() = calledNumbers.lastOrNull()
    val calledCount: Int get() = calledNumbers.size
    val remainingCount: Int get() = TOTAL_NUMBERS - calledCount
    val isComplete: Boolean get() = calledCount >= TOTAL_NUMBERS
    val hasStarted: Boolean get() = calledNumbers.isNotEmpty()
    val intervalMs: Long get() = intervalSeconds * 1000L

    /** 0.0 right after a number is called, 1.0 when the next one is due. */
    val countdownProgress: Float
        get() = (elapsedMs.toFloat() / intervalMs).coerceIn(0f, 1f)

    val secondsUntilNext: Int
        get() = ceil((intervalMs - elapsedMs).coerceAtLeast(0L) / 1000.0).toInt()

    companion object {
        const val TOTAL_NUMBERS = 90
        const val MIN_INTERVAL = 3
        const val MAX_INTERVAL = 15
        const val DEFAULT_INTERVAL = 5
    }
}

/**
 * Holds the game. Because it is a ViewModel it is NOT destroyed when the screen
 * rotates, so the board, history and running timer all carry on untouched.
 *
 * [SavedStateHandle] additionally saves the important bits (called numbers, mode,
 * interval, mute) so they come back even if Android kills the app in the background.
 */
class GameViewModel(
    application: Application,
    private val savedStateHandle: SavedStateHandle,
) : AndroidViewModel(application) {

    private val speaker = TambolaSpeaker(application)

    private val _uiState = MutableStateFlow(restoreFromSavedState())
    val uiState: StateFlow<GameUiState> = _uiState.asStateFlow()

    private var autoCallJob: Job? = null

    init {
        speaker.setOnStatusChangedListener { status ->
            _uiState.update { it.copy(voiceStatus = status) }
        }
    }

    // ---------------------------------------------------------------- Home screen

    fun selectMode(mode: CallMode) {
        if (mode == _uiState.value.mode) return
        pause()
        updateState { it.copy(mode = mode, elapsedMs = 0L) }
    }

    fun setInterval(seconds: Int) {
        val safe = seconds.coerceIn(GameUiState.MIN_INTERVAL, GameUiState.MAX_INTERVAL)
        updateState { it.copy(intervalSeconds = safe, elapsedMs = 0L) }
    }

    fun openGame() {
        updateState { it.copy(screen = Screen.GAME) }
    }

    fun goHome() {
        pause()
        updateState { it.copy(screen = Screen.HOME) }
    }

    // ---------------------------------------------------------------- Game controls

    /** Start button in Auto mode. Calls numbers on a timer until paused or finished. */
    fun start() {
        val state = _uiState.value
        if (state.mode != CallMode.AUTO || state.isComplete || state.isRunning) return

        updateState(persist = false) { it.copy(isRunning = true) }
        autoCallJob?.cancel()
        autoCallJob = viewModelScope.launch {
            // Fresh game: call the first number straight away.
            if (!_uiState.value.hasStarted) drawNextNumber()

            while (isActive && !_uiState.value.isComplete) {
                // Count up in small ticks so the progress bar moves smoothly.
                // If we were paused half-way, this resumes from where we stopped.
                while (_uiState.value.elapsedMs < _uiState.value.intervalMs) {
                    delay(TICK_MS)
                    updateState(persist = false) { it.copy(elapsedMs = it.elapsedMs + TICK_MS) }
                }
                drawNextNumber()
            }
            updateState(persist = false) { it.copy(isRunning = false) }
        }
    }

    fun pause() {
        autoCallJob?.cancel()
        autoCallJob = null
        if (_uiState.value.isRunning) {
            updateState(persist = false) { it.copy(isRunning = false) }
        }
    }

    fun toggleStartPause() {
        if (_uiState.value.isRunning) pause() else start()
    }

    /** "Next Number" button in Manual mode. */
    fun nextNumber() {
        drawNextNumber()
    }

    /** Says the current number again (handy if someone missed it). */
    fun repeatCurrent() {
        val state = _uiState.value
        val number = state.currentNumber ?: return
        if (!state.isMuted) speaker.announce(number)
    }

    fun toggleMute() {
        val nowMuted = !_uiState.value.isMuted
        if (nowMuted) speaker.stop()
        updateState { it.copy(isMuted = nowMuted) }
    }

    /** Clears the board and history and starts a brand-new game. */
    fun resetGame() {
        pause()
        speaker.stop()
        updateState { it.copy(calledNumbers = emptyList(), elapsedMs = 0L) }
    }

    // ---------------------------------------------------------------- Internals

    /** Picks a random number that hasn't been called yet, records it and announces it. */
    private fun drawNextNumber(): Int? {
        val state = _uiState.value
        if (state.isComplete) return null

        val alreadyCalled = state.calledNumbers.toHashSet()
        val number = (1..GameUiState.TOTAL_NUMBERS).filterNot { it in alreadyCalled }.random()

        updateState { it.copy(calledNumbers = it.calledNumbers + number, elapsedMs = 0L) }
        if (!_uiState.value.isMuted) speaker.announce(number)
        return number
    }

    /**
     * Changes the state and (by default) saves the important fields so they
     * survive the app being killed in the background. Timer ticks skip saving.
     */
    private fun updateState(persist: Boolean = true, change: (GameUiState) -> GameUiState) {
        _uiState.update(change)
        if (persist) saveToSavedState(_uiState.value)
    }

    private fun saveToSavedState(state: GameUiState) {
        savedStateHandle[KEY_SCREEN] = state.screen.name
        savedStateHandle[KEY_MODE] = state.mode.name
        savedStateHandle[KEY_INTERVAL] = state.intervalSeconds
        savedStateHandle[KEY_CALLED] = state.calledNumbers.toIntArray()
        savedStateHandle[KEY_MUTED] = state.isMuted
    }

    private fun restoreFromSavedState(): GameUiState = GameUiState(
        screen = savedStateHandle.get<String>(KEY_SCREEN)
            ?.let { runCatching { Screen.valueOf(it) }.getOrNull() } ?: Screen.HOME,
        mode = savedStateHandle.get<String>(KEY_MODE)
            ?.let { runCatching { CallMode.valueOf(it) }.getOrNull() } ?: CallMode.AUTO,
        intervalSeconds = savedStateHandle.get<Int>(KEY_INTERVAL) ?: GameUiState.DEFAULT_INTERVAL,
        calledNumbers = savedStateHandle.get<IntArray>(KEY_CALLED)?.toList() ?: emptyList(),
        isMuted = savedStateHandle.get<Boolean>(KEY_MUTED) ?: false,
    )

    override fun onCleared() {
        autoCallJob?.cancel()
        speaker.shutdown()
        super.onCleared()
    }

    private companion object {
        const val TICK_MS = 100L
        const val KEY_SCREEN = "screen"
        const val KEY_MODE = "mode"
        const val KEY_INTERVAL = "interval"
        const val KEY_CALLED = "called_numbers"
        const val KEY_MUTED = "muted"
    }
}
