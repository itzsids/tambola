import org.jetbrains.kotlin.gradle.dsl.JvmTarget

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

// ---------------------------------------------------------------------------
// Values that come from GitHub (repository "Variables" and "Secrets").
// If they are missing, safe defaults are used so the build still works.
// ---------------------------------------------------------------------------
fun env(name: String): String? = System.getenv(name)?.trim()?.takeIf { it.isNotEmpty() }

// Google's official TEST ad IDs. They show "Test Ad" banners and never pay,
// but they are always safe to use (you can't get banned for clicking them).
val testAppId = "ca-app-pub-3940256099942544~3347511713"
val testBannerId = "ca-app-pub-3940256099942544/9214589741"
val testInterstitialId = "ca-app-pub-3940256099942544/1033173712"

// Your REAL AdMob IDs (only used in the release / Play Store build).
val realAppId = env("ADMOB_APP_ID") ?: testAppId
val realBannerId = env("ADMOB_BANNER_ID") ?: testBannerId
val realInterstitialId = env("ADMOB_INTERSTITIAL_ID") ?: testInterstitialId

// Every GitHub build gets a higher number automatically (Play Store needs this).
val buildNumber = env("GITHUB_RUN_NUMBER")?.toIntOrNull() ?: 1

// Upload key for signing the Play Store build.
val keystorePath = env("KEYSTORE_FILE")
val keystorePassword = env("KEYSTORE_PASSWORD")

android {
    namespace = "com.tambola.announcer"
    compileSdk = 36

    defaultConfig {
        // Package name on Google Play. It can NEVER be changed after the first upload.
        applicationId = "com.onewaydevelopers.tambola"
        minSdk = 24
        targetSdk = 36
        versionCode = buildNumber
        versionName = "1.0.$buildNumber"
    }

    signingConfigs {
        if (keystorePath != null && keystorePassword != null) {
            create("upload") {
                storeFile = file(keystorePath)
                storePassword = keystorePassword
                keyAlias = env("KEY_ALIAS") ?: "upload"
                keyPassword = keystorePassword
            }
        }
    }

    buildTypes {
        debug {
            // Test build: always uses Google's test ads.
            applicationIdSuffix = ".debug"
            manifestPlaceholders["admobAppId"] = testAppId
            buildConfigField("String", "BANNER_AD_ID", "\"$testBannerId\"")
            buildConfigField("String", "INTERSTITIAL_AD_ID", "\"$testInterstitialId\"")
        }
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
            signingConfig = signingConfigs.findByName("upload")
            manifestPlaceholders["admobAppId"] = realAppId
            buildConfigField("String", "BANNER_AD_ID", "\"$realBannerId\"")
            buildConfigField("String", "INTERSTITIAL_AD_ID", "\"$realInterstitialId\"")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    buildFeatures {
        compose = true
        buildConfig = true
    }
}

kotlin {
    compilerOptions {
        jvmTarget.set(JvmTarget.JVM_17)
    }
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2025.08.00")
    implementation(composeBom)

    implementation("androidx.core:core-ktx:1.16.0")
    implementation("androidx.activity:activity-compose:1.10.1")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.9.2")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.9.2")

    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")

    // Ads (AdMob) + the consent popup required for users in Europe/UK.
    implementation("com.google.android.gms:play-services-ads:25.1.0")
    implementation("com.google.android.ump:user-messaging-platform:3.2.0")

    debugImplementation("androidx.compose.ui:ui-tooling")

    testImplementation("junit:junit:4.13.2")
}
